﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace COMP10203_Lab1B.Data.Migrations
{
    public partial class Dealership : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
